/******************************************************************************
 * element 5 / ShareIt!
 * Key-Generator-DLL Example and Template
 * for use with Borland C++ 5.5
 * (available from www.borland.com/bcppbuilder/freecompiler)
 *
 * Compile from the console using:
 * BCC32 -tWD key_bcb.c
 ******************************************************************************/

#include <string.h>
#include <windows.h>
#include "key_intf.h"

#define DLLEXPORT __declspec( dllexport )

/* pointers to input values will be stored here by the parser 
 * values are initialized to point to an empty string */

static char EMPTY[] = ""; /* empty string used for initialization */

/* initialize variables fro input values */
char *reg_name = EMPTY;
char *email = EMPTY;
int language = liEnglish;

/* parse input array and assign values to variables */
int
ParseInput(char *args[])
{
  /* check for null array pointer */
  if (!args) return -1;

  /* get input values from array */
  while (args)
  {
    char *tag, *value;

    /* get next tag */
    tag = *args++;
    if (!tag)	break;

    /* get assigned value for tag */
    value = *args++;
    if (!value)	break; /* oops a tag without a value */

    /* assign tag value */
    /* ADD MORE VALUES AS YOU NEED THEM */
    if (!stricmp(tag, "REG_NAME")) reg_name = value;
    else if (!stricmp(tag, "EMAIL")) email = value;
    else if (!stricmp(tag, "LANGUAGE_ID")) language = atoi(value);
  }
  return 0;
}

/* example algorithm */
unsigned int 
CalcKey(char *s)
{
  unsigned int key = 0;
  
  while (*s)
  {
    key += *s++;
    key <<= 2;
  }  
  return key;
}    
 
/* generate a key from the supplied input
 * 4000 bytes of memory have been allocated for each result 
 * you should ensure that your output does not get longer ! */
DLLEXPORT int __stdcall
GenKeyEx(char * args[], char *result1, char *result2)
{
  unsigned int key;

  /* parse input array */
  if (ParseInput(args) < 0)
  {
    strcpy(result1, "Could not parse args!");
    return ERC_BAD_INPUT;
  }    

  /* first check for valid input */
  if (strlen(reg_name) < 8) 
  {
    strcpy(result1, "<reg_name> must have at least 8 characters!");
    return ERC_BAD_INPUT;
  }

  if (strlen(email) < 6) 
  {
    strcpy(result1, "<email> must have at least 6 characters!");
    return ERC_BAD_INPUT;
  }

  /* generate the cckey */
  key = CalcKey(reg_name);
  wsprintf(result2, "%x", key);

  /* generate the userkey */
  if (language == liGerman)
    wsprintf(result1, "Benutzer: %s\r\nSchl�ssel: %x", reg_name, key);
  else
    wsprintf(result1, "Username: %s\r\nKey: %x", reg_name, key);

  return ERC_SUCCESS;
}

/* DLL init/cleaup code goes here */
int WINAPI
DllEntryPoint(HINSTANCE hinstDLL, unsigned long fdwReason, void * lpvReserved)
{
  switch(fdwReason)
  {
    case DLL_PROCESS_ATTACH: /* init */
    break;

    case DLL_PROCESS_DETACH: /* cleanup */
    break;
  };
  return TRUE;
};
